/**
 * 场景管理
 */

// TODO: 新的场景管理器，可能只需要管理 conponents 即可了