Sprite
====

Interoperable Sprite & Layer