FSM
====

Finite state machine